"""
Le script ci-dessous montre comment créer une première fenêtre noire avec Pygame.
1) Exécuter le script avec le débogueur en mode pas à pas pour bien identifier ce que fait chaque ligne.
2) Exécuter ensuite en mode normal (sans débogueur). Quel est le problème ?
"""
import pygame

pygame.init()

fenetre = pygame.display.set_mode((300, 200))
pygame.display.set_caption("Titre de la fenêtre")

pygame.quit()