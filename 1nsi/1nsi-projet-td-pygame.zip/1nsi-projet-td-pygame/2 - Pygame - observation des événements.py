"""
Le script ci-dessous permet de visualiser les événements que reçoit pygame.
1) Lire attentivement le code pour en comprendre le fonctionnement.
2) Exécuter le script et survoler brièvement la fenêtre pygame avec la souris pour observer les événement générés.
3) Pourquoi y a-t-il encore des événements qui s'affichent pendant une fraction de seconde
   après que l'on ait retiré la souris de la fenêtre ?
4) Appuyer sur plusieurs touches du clavier pour observer les événements générés.
5) Cacher à moitié la fenêtre Pygame derrière une autre fenêtre, puis :
   - Survoler cette dernière avec la souris. Que remarque-t-on ?
   - Appuyer sur plusieurs touches du clavier. Que remarque-t-on ?
6) Cliquer sur la fenêtre Pygame, la déplacer et la redimensionner pour observer les événements générés.
"""
import pygame

pygame.init()

fenetre = pygame.display.set_mode((200, 200),pygame.RESIZABLE)

continuer = True
while continuer:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            continuer = False
        print(event.type, "\t", pygame.event.event_name(event.type))
        
    pygame.display.update()

pygame.quit()