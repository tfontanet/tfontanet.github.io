"""
Le script ci-dessous montre comment afficher une image et déplacer une image sur une autre.
1) Lire attentivement le code pour en comprendre la structure générale.
2) Chercher dans la doc Pygame ce que font pygame.image.load, .convert() et .convert_alpha() (lignes 16 et 19)
3) Chercher dans la doc Pygame ce que font .blit() et pygame.display.update() (lignes 17, 22, 32, 34 et 38)
4) Chercher dans la doc Pygame ce qu'est un Rect et ce que font .get_rect() et .move_ip() (lignes 20 et 21)
5) Chercher dans la doc Pygame ce que font clock = pygame.time.Clock() et clock.tick(40) (lignes 24 et 39)
6) Bien comprendre les lignes 32 à 34 ainsi que 36!
"""
import pygame

pygame.init()

fenetre = pygame.display.set_mode((1180, 530))

fond = pygame.image.load("mer.gif").convert()
fenetre.blit(fond,(0,0))

bateau = pygame.image.load("bateau.png").convert_alpha()
rect_bateau = bateau.get_rect()
rect_bateau.move_ip(0, 300)
fenetre.blit(bateau, rect_bateau)

clock = pygame.time.Clock()

continuer = True
while continuer :
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            continuer = False
    
    fenetre.blit(fond, rect_bateau, rect_bateau)
    rect_bateau.left += 5
    fenetre.blit(bateau, rect_bateau)
   
    rect_bateau.left %= 1180

    pygame.display.update()
    clock.tick(40)
pygame.quit()
