"""
Le script ci-dessous montre comment détecter les collisions entre deux sprites en utilisant des masques.
1) Lire attentivement le code pour en comprendre la structure générale.
2) On cherche ci-dessous à détecter les collisions entre la baleine et le bateau.
   Pour cela, on a créé un rect et un masque pour chacune de ces deux surfaces.
   A quel moment les utilise-t-on ?
3) Chercher dans la doc Pygame ce que fait pygame.mask.from_surface() (lignes 21 et 27)
4) Bien comprendre ce que font les 4 lignes exécutée suite à un événement MOUSEMOTION 
5) Chercher dans la doc Pygame ce que fait mask_baleine.overlap(mask_bateau, (offset_x, offset_y)) (ligne 45)
"""
import pygame

pygame.init()

fenetre = pygame.display.set_mode((1180, 530))

fond = pygame.image.load("mer.gif").convert()
fenetre.blit(fond,(0,0))

bateau = pygame.image.load("bateau.png").convert_alpha()
mask_bateau = pygame.mask.from_surface(bateau)
rect_bateau = bateau.get_rect()
rect_bateau.move_ip(400,300)
fenetre.blit(bateau, rect_bateau)

baleine = pygame.image.load("baleine.png").convert_alpha()
mask_baleine = pygame.mask.from_surface(baleine)
rect_baleine = baleine.get_rect()

clock = pygame.time.Clock()

continuer = True
while continuer :
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            continuer = False
        elif event.type == pygame.MOUSEMOTION:
            fenetre.blit(fond, rect_baleine, rect_baleine)
            fenetre.blit(bateau, (400,300))
            rect_baleine.center = event.pos
            fenetre.blit(baleine, rect_baleine)
    
    offset_x = rect_bateau.x - rect_baleine.x
    offset_y = rect_bateau.y - rect_baleine.y
    if mask_baleine.overlap(mask_bateau, (offset_x, offset_y)):
        print("Aîe !!!!")
    else:
        print("")

    pygame.display.update()
    clock.tick(40)
pygame.quit()
