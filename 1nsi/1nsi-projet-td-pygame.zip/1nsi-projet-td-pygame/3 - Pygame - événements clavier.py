"""
Le script ci-dessous montre comment utiliser les événements claviers.
1) Lire attentivement le code pour en comprendre le fonctionnement.
2) Appuyer sur la touche "a" (minuscule) :
    - Dans quel ordre sont générés les évenements ?
    - Chercher dans la documentation Pygame la signification des attributs key, mod et unicode.
3) Tester ensuite les touches ci-dessous en vérifiant à chaque fois les événements générés et leurs attributs.
    Touches à tester : A (majuscule), &, #, tabulation, shift, entrée, F1
    (Entre 2 touches, on peut cliquer sur la fenêtre Pygame pour introduire une séparation entre les messages)
4) Appui long sur une touche :
    - Laisser appuyé la touche "a" du clavier. Les événements sont-ils tous répétés ?
    - Comment détecter un appui long sur une flèche ? (cas par exemple où on veut déplacer un sprite)
"""
import pygame
pygame.init()
fenetre = pygame.display.set_mode((100,100))

continuer = True
while continuer:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            continuer = False
        elif event.type == pygame.KEYDOWN:
            print("Evenement KEYDOWN :")
            print("     event.key : " + str(hex(event.key)))
            print("     event.mod : " + str(hex(event.mod)))
            print("     event.unicode : " + event.unicode)
            print("     event.scancode : " + str(hex(event.scancode)))
            print("     pygame.key.name(event.key) : " + pygame.key.name(event.key))
        elif event.type == pygame.KEYUP:
            print("Evenement KEYUP :")
            print("     event.key : " + str(hex(event.key)))
            print("     event.mod : " + str(hex(event.mod)))
        elif event.type == pygame.TEXTINPUT:
            print("Evenement TEXTINPUT :")
            print("     event.text : " + event.text)
        elif event.type == pygame.MOUSEBUTTONUP:
            print("----------------------------------")

pygame.quit()
