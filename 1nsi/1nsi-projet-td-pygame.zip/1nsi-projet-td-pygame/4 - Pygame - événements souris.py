"""
Le script ci-dessous montre comment utiliser les événements souris.
1) Lire attentivement le code pour en comprendre le fonctionnement.
2) Exécuter le script et cliquer sur la fenêtre Pygame :
   - Dans quel ordre sont générés les événements ?
   - L'attribut "button" peut prendre les valeurs 1, 2, 3, 4 et 5.
     Saurez-vous retrouver à quels boutons de la souris elles correspondent ?
   - Les positions sont indiquées dans quelle unité ? et relativement à quoi ?
3) Que faut-il faire pour afficher les événements MOUSEMOTION avec le script ci-dessous ?
4) L'événement MOUSEMOTION se déclenche dès que la souris est au-dessus de la fenêtre
   ou bien seulement si la souris bouge au-dessus de la fenêtre ?
"""
import pygame
pygame.init()
fenetre = pygame.display.set_mode((400,200))

continuer = True
while continuer:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            continuer = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            print("Evenement MOUSEBUTTONDOWN :")
            print(f"position:{event.pos}, bouton:{event.button}")
        elif event.type == pygame.MOUSEBUTTONUP:
            print("Evenement MOUSEBUTTONUP :")
            print(f"position:{event.pos}, bouton:{event.button}")
        elif event.type == pygame.MOUSEMOTION and pygame.key.get_pressed()[pygame.K_SPACE]:
            print("Evenement MOUSEMOTION :")
            print(f"position:{event.pos}, boutons:{event.buttons}, position précédente:{event.rel}")

pygame.quit()

