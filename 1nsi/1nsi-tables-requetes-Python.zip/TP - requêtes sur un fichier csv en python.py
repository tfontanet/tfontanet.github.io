import csv

#########################################
# Requêtes sur un fichier csv en Python #
#########################################


# Requête 1 : Sélection
def compte_humains():
    """ Renvoie le nombre d'humains dans la table characters.csv """
    pass
        
# assert compte_humains() == 35



# Requête 2 : Sélection
def compte_droïdes_aux_yeux_rouges():
    """ Renvoie le nombre de droïdes aux yeux rouges """
    pass

# assert compte_droïdes_aux_yeux_rouges() == 3



# Requête 3 : Sélection
def compte_grands_personnages():
    """ Renvoie le nombre de personnages de 2 mètres et plus """
    pass

# assert compte_grands_personnages() == 11



# Requête 4 : Sélection
def sélectionne_personnages_marrons():
    """ Renvoie les noms et couleurs de peau des personnages starwars pour ceux dont la couleur de peau contient du marron.
        Le résultat sera une liste de tuples. """
    pass

# assert len(sélectionne_personnages_marrons()) == 7
# assert ('Ackbar', 'brown mottle') in sélectionne_personnages_marrons()



# Requête 5 : Tri
def taille(personnage):
    if personnage['height'] == '':
        return 0
    else:
        return int(personnage['height'])

def tri_par_tailles():
    """ Renvoie les noms des personnages starwars triés par taille décroissante.
        Le résultat sera une liste de chaines de caractères
        Pour le tri, on pourra utiliser la fonction sorted(..., key=taille) pour trier la liste des dictionnaires.
        (Chercher sur internet comment fonctionne "sorted(..., key=...)". C'est un peu subtil !) """
    pass
    
# assert tri_par_tailles()[:5] == ['Yarael Poof', 'Tarfful', 'Lama Su', 'Chewbacca', 'Roos Tarpals']



# Requête 6 : Tri
def nom(personnage):
    return personnage['name']
    
def tri_par_noms():
    """ Renvoie la liste des noms des personnages triés par ordre alphabétique. """
    pass
    
# assert tri_par_noms()[:5] == ['Ackbar', 'Adi Gallia', 'Anakin Skywalker', 'Arvel Crynyd', 'Ayla Secura']



# Requête 7 : Jointure
def sélectionne_noms_et_planètes():
    """ Renvoie les noms des personnages starwars ainsi que les noms de leurs planètes d'origine.
        Le résultat sera une liste de tuples.
        Les noms des planètes se trouvent dans la table "planets.csv".
        Il faudra donc mettre en commun les données de 2 tables différentes """
    pass

# assert len(sélectionne_noms_et_planètes()) == 87
# assert ('Luke Skywalker', 'Tatooine') in sélectionne_noms_et_planètes()
# assert ('Padmé Amidala', 'Naboo') in sélectionne_noms_et_planètes()



# Requête 8 : Jointure et sélection
def sélectionne_habitants_planètes_tempérées():
    """ Renvoie les noms des personnages starwars dont la planète d'origine est tempérée. """
    pass

# assert len(sélectionne_habitants_planètes_tempérées()) == 47
# assert 'Luke Skywalker' not in sélectionne_habitants_planètes_tempérées()
# assert 'C-3PO' not in sélectionne_habitants_planètes_tempérées()
# assert 'Leia Organa' in sélectionne_habitants_planètes_tempérées()
# assert 'Obi-Wan Kenobi' in sélectionne_habitants_planètes_tempérées()
