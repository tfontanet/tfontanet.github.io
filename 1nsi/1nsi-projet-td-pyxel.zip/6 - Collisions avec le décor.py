"""
Appuyer sur les flèches du clavier pour déplacer le personnage
Le but de cet exemple est de comprendre comment gérer les collisions
avec les tuiles d'une tilemap
"""

import pyxel

pyxel.init(128, 128)
pyxel.load("tuto.pyxres")

xperso = 20
yperso = 24

tuiles_mur = [(6, 11)]

def update():
    global xperso, yperso
    dx, dy = 0, 0
    if pyxel.btn(pyxel.KEY_LEFT):
        dx = -2
    elif pyxel.btn(pyxel.KEY_RIGHT):
        dx = 2
    elif pyxel.btn(pyxel.KEY_UP):
        dy = -2
    elif pyxel.btn(pyxel.KEY_DOWN):
        dy = 2
    dx, dy = pyxel.tilemaps[1].collide(xperso, yperso, 8, 8, dx, dy, tuiles_mur)
    xperso += dx
    yperso += dy
    
    xperso = pyxel.clamp(xperso, 0, 128-8)
    yperso = pyxel.clamp(yperso, 0, 128-8)
        
def draw():
    pyxel.cls(0)
    # Affichage du décor
    pyxel.bltm(0, 0, 1, 0, 0, 128, 128)
    # Affichage du personnage
    pyxel.blt(xperso, yperso, 0, 16, 0, 8, 8, colkey=pyxel.COLOR_BLACK)

pyxel.run(update, draw)

"""
Votre travail :
1) Etudier sérieusement le fonctionnement du programme dans les détails.
2) Laquelle des tilemaps de "tuto.pyxres" affiche-t-on ici ?
3) Déplacer le personnage et vérifier qu'il ne travers pas les murs !
4) Identifier les lignes du code ou on gère les collisions avec les tuiles.
   Bien comprendre l'utilité de chacun des paramètres de la méthode collide.
5) Comprendre comment on a trouvé les coordonnées des tuiles utilisées
   pour les murs.
6) Que fait "pyxel.clamp()" ?
"""