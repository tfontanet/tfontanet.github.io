"""
Appuyer sur la touche espace pour faire sauter le carré vert
Le but de cet exemple est de comprendre comment simuler la gravité
"""

import pyxel

pyxel.init(160, 100, "Saut")
xrect = 0
yrect = 92
dyrect = 0
sol = 100

def update():
    global xrect, yrect, dyrect
    
    # Défilement horizontal du rectangle à chaque frame
    xrect = (xrect + 1) % 160
        
    # Pour sauter, appuyer sur la touche Espace
    if pyxel.btnp(pyxel.KEY_SPACE):
        # On ne peut sauter que si on est au sol
        if yrect+8 == sol:
            force_saut = -10
            dyrect = force_saut
        
    # Appliquer la gravité sur la vitesse verticale
    gravité = 1
    dyrect += gravité
    yrect += dyrect

    # Collision avec le sol
    if yrect+8 > sol:
        yrect = sol-8
    else:
        print(f"{dyrect}, {yrect}")

def draw():
    pyxel.cls(0)
    # Dessiner le joueur (carré 8x8)
    pyxel.rect(xrect, yrect, 8, 8, pyxel.COLOR_GREEN)

pyxel.run(update, draw)

"""
Votre travail :
1) Etudier sérieusement le fonctionnement du programme dans les détails.
2) Quelle forme mathématique a la trajectoire d'un saut ?
3) Modifier les valeurs de "gravité" et "force_saut"
   et observer l'effet sur les sauts.
4) Observer et comprendre les valeurs affichées dans la console à chaque saut.
5) Dans la ligne "if pyxel.btnp(pyxel.KEY_SPACE):",
   pourquoi a-t-on choisi "btnp" plutôt que "btn" ?
"""