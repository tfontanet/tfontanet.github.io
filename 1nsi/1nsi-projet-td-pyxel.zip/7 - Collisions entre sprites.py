"""
Appuyer sur les flèches du clavier pour que le personnage évite les bombes.
Le but de cet exemple est de comprendre comment gérer les collisions entre sprites
"""

import pyxel, random

pyxel.init(128, 128)
pyxel.load("tuto.pyxres")

afficher_perso = True
xperso = 20
yperso = 100

bombes = []

explosion = {"début":-1, "numsprite":-1}

def collision(r1xmin, r1ymin, r1xmax, r1ymax, r2xmin, r2ymin, r2xmax, r2ymax):
    # Le fonctionnement de cette fonction est expliqué sur mon site
    # dans le pdf "Gestion des collisions : entre deux rectangles"
    return not (r1xmax < r2xmin or r1xmin > r2xmax or r1ymax < r2ymin or r1ymin > r2ymax)

def update():
    global xperso, yperso, afficher_perso

    if afficher_perso:
        # Toutes les demi secondes, on lance une nouvelle bombe
        if pyxel.frame_count%15 == 0:
            x = random.randint(0, 128-8)
            bombe = {"x":x, "y":-8}
            bombes.append(bombe)
        
        # A chaque frame, on fait descendre toutes les bombes d'un pixel
        for bombe in bombes:
            bombe["y"] += 1
        
        # Si la plus ancienne bombe est en bas de l'écran, on la supprime
        if bombes[0]["y"] > 128:
            del bombes[0]
    
        # Déplacement du personnage
        if pyxel.btn(pyxel.KEY_LEFT):
            xperso += -2
        elif pyxel.btn(pyxel.KEY_RIGHT):
            xperso += 2
        elif pyxel.btn(pyxel.KEY_UP):
            yperso += -2
        elif pyxel.btn(pyxel.KEY_DOWN):
            yperso += 2
        
        xperso = pyxel.clamp(xperso, 0, 128-8)
        yperso = pyxel.clamp(yperso, 0, 128-8)
        
        # On vérifie que le personnage n'est en collision avec aucune bombe
        i = 0
        while i < len(bombes):
            if collision(xperso, yperso, xperso+8, yperso+8, bombes[i]["x"], bombes[i]["y"], bombes[i]["x"]+6, bombes[i]["y"]+6):
                del bombes[i]
                afficher_perso = False
                explosion["début"] = pyxel.frame_count
                explosion["numsprite"] = -8
            i += 1
    
    # En cas d'explosion, on définit le sprite à utiliser
    else:
        if explosion["numsprite"] < 40:
            nbre_frames_depuis_explosion = pyxel.frame_count - explosion["début"]
            if nbre_frames_depuis_explosion % 4 == 0:
                explosion["numsprite"] += 8
        else:
            explosion["début"] = -1
                
def draw():
    pyxel.cls(0)
    # Affichage des bombes
    for bombe in bombes:
        pyxel.blt(bombe["x"], bombe["y"], 0, 73, 26, 6, 6, colkey=pyxel.COLOR_BLACK)
    # Affichage du personnage
    if afficher_perso:
        pyxel.blt(xperso, yperso, 0, 16, 0, 8, 8, colkey=pyxel.COLOR_BLACK)
    # Affichage de l'explosion (à l'endroit du personnage)   
    elif explosion["début"] > 0:
        pyxel.blt(xperso, yperso, 0, explosion["numsprite"], 32, 8, 8, colkey=pyxel.COLOR_BLACK, scale=2)

pyxel.run(update, draw)

"""
Votre travail :
1) Etudier sérieusement le fonctionnement du programme dans les détails.
2) Bien regarder le pdf d'explications sur le fonctionnement de la fonction "collision"
   qui est sur mon site.
3) Vérifier les paramètres qui ont été donnés lors de l'appel de "collision"
4) Dans la boucle qui permet de vérifier que le personnage n'est en collision avec
   aucune bombe, pourquoi utilise-t-on un "while" et non un "for" ?
5) Observer la façon dont est gérée l'évolution de l'explosion. Combien de temps dure-t-elle ?
"""