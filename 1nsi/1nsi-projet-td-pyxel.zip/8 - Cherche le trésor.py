"""
Dans cet exemple, on peut déplacer le personnage avec les flèches du clavier
et la barre d'espace. Le but est d'éviter les rivières de feu et d'aller
jusqu'au coffre fort tout à droite.

C'est l'occasion :
- d'utiliser une tilemap pour générer un décor
- d'apprendre à faire glisser le décor dans l'écran
- d'utiliser la fonction collide pour gérer les collisions avec le décor
- d'apprendre à gérer la gravité et les sauts
"""

import pyxel

pyxel.init(256, 128)
pyxel.load("tuto.pyxres")

# Positions de départ du personnage et de la map
xmap = 0       # abscisse gauche de la partie de la map qui est affichée
xperso = 10   # abscisse gauche du personnage dans la map
yperso = 8*8  # ordonnée haute du personnage dans la map
usprite = 32   # abscisse gauche du sprite utilisé pour le personnage dans l'image 0
dyperso = 0   # déplacement vertical entre 2 frames pour simuler la gravité

# Définition des tuiles avec lesquelles il faudra étudier les collisions
sol_et_murs = [(7,13), (9,13), (11,13), (1,11), (6,11), (2,10), (13,13), (1,14)]
terrasses = [(6,6), (5,5)]
toit_temple = [(1,15), (7,15), (2,15)]
tuiles_intraversables = sol_et_murs + terrasses + toit_temple

def update():
    global xmap, xperso, yperso, uperso, dyperso
    # 1) Déplacements horizontaux de la map et du personnage:
    if pyxel.btn(pyxel.KEY_RIGHT):
        # On essaye de déplacer le personnage de 2 pixels vers la droite dans la map
        # et on vérifie qu'aucune collision avec le décors n'empêche ce déplacement
        dx = 2
        dx, dy = pyxel.tilemaps[0].collide(xperso, yperso, 8, 8, dx, 0, tuiles_intraversables)
        xperso += dx
        if (xperso - xmap < 256//3) or (xmap >= 768 - 256):
            # Si le personnage est dans le 1/3 gauche de l'écran,
            # ou bien que l'on ne peut plus faire glisser la map :
            # alors on fait glisser seulement le personnage
            xmap += 0
        elif (xmap < 768 - 256) and (xperso - xmap < 2*256//3):
            # Si on peut faire glisser la map
            # et que le personnage est dans le 1/3 du milieu :
            # alors on fait glisser personnage et map en sens inverse
            xmap += dx//2
        elif (xmap < 768 - 256):
            # Si on peut faire glisser la map
            # et que le personnage est dans le 1/3 droit :
            # alors on fait glisser seulement la map
            xmap += dx
        # Choix du sprite à afficher pour simuler la marche
        if pyxel.frame_count%10 <= 5:
            usprite = 32
        else:
            usprite = 40
    if pyxel.btn(pyxel.KEY_LEFT):
        # On essaye de déplacer le personnage de 2 pixels vers la gauche dans la map
        # et on vérifie qu'aucune collision avec le décors n'empêche ce déplacement
        dx = -2
        dx, dy = pyxel.tilemaps[0].collide(xperso, yperso, 8, 8, dx, 0, tuiles_intraversables)
        xperso += dx
        if (xperso - xmap > 2*256//3) or (xmap <= 0):
            # Si le personnage est dans le 1/3 droit de l'écran,
            # ou bien que l'on ne peut plus faire glisser la map :
            # alors on fait glisser seulement le personnage
            xmap += 0
        elif (xmap > 0) and (xperso - xmap > 256//3):
            # Si on peut faire glisser la map
            # et que le personnage est dans le 1/3 du milieu :
            # alors on fait glisser personnage et map en sens inverse
            xmap += dx//2
        elif xmap > 0:
            # Si on peut faire glisser la map
            # et que le personnage est dans le 1/3 gauche :
            # alors on fait glisser seulement la map
            xmap += dx
        # Choix du sprite affiché pour simuler la marche
        if pyxel.frame_count%10 <= 5:
            usprite = 0
        else:
            usprite = 8
    
    # 2) Déplacement vertical du personnage:
    if pyxel.btnp(pyxel.KEY_SPACE):
        if pyxel.tilemaps[0].pget((xperso+4)//8, (yperso+4)//8) == (11,14):
            # Le centre du personnage est sur un escalier donc il va grimper l'escalier
            # On force l'alignement horizontal du sprite sur l'escalier
            xperso = ((xperso+4)//8)*8
            # Et on monte l'escalier en faisant un grand saut
            # (remonte de 11 pour la première frame)
            dyperso = -11
        elif pyxel.tilemaps[0].collide(xperso, yperso, 8, 8, 0, 1, tuiles_intraversables) == (0, 0):
            # Le personnage est posé sur le sol donc il peut sauter
            # (remonte de 7 pour la première frame)
            dyperso = -7
            
    # 3) Gravité du personnage:
    gravité = 1
    dyperso += gravité
    dx, dyperso = pyxel.tilemaps[0].collide(xperso, yperso, 8, 8, 0, dyperso, tuiles_intraversables)
    yperso += dyperso

    # La partie de la map affichée doit être incluse dans la map totale
    xmap = pyxel.clamp(xmap, 0, 768-256)
    # Le personnage doit être entièrement dans l'écran
    xperso = pyxel.clamp(xperso, xmap, xmap+256-8)
    yperso = pyxel.clamp(yperso, 0, 128-8)

def draw():
    pyxel.cls(0)
    # Affichage des nuages
    pyxel.bltm(0, 0, 0, xmap//16, 0, 256, 64)
    # Affichage du décors
    pyxel.bltm(0, 64, 0, xmap, 64, 256, 128)
    # Affichage du personnage
    pyxel.blt(xperso - xmap, yperso, 0, usprite, 8, 8, 8, pyxel.COLOR_BLACK)
    # Affichage du "Game over" si le personnage est tombé dans le feu
    if yperso == 128-8:
        pyxel.text(105, 60, "Game over !", pyxel.COLOR_LIME)
    # Affichage du "Bravo" si le personnage est devant le coffre fort
    if 664 < xperso < 678 and yperso == 96:
        pyxel.text(90, 60, "Bravo, c'est le coffre !", pyxel.COLOR_LIME)


pyxel.run(update, draw)